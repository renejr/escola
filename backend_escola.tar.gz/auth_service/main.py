from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel
import uvicorn
from dotenv import load_dotenv
import os
import jwt
from datetime import datetime, timedelta
import bcrypt
import asyncpg

load_dotenv()

app = FastAPI(title="Auth Service - SaaS Escolar")

DATABASE_URL = os.getenv("DATABASE_URL")
JWT_SECRET = os.getenv("JWT_SECRET")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 1 dia

class LoginRequest(BaseModel):
    email: str
    password: str

async def get_db():
    conn = await asyncpg.connect(DATABASE_URL)
    try:
        yield conn
    finally:
        await conn.close()

@app.post("/auth/login")
async def login(req: LoginRequest, conn: asyncpg.Connection = Depends(get_db)):
    # Buscar usuário no banco
    query = "SELECT id, escola_id, papel, senha_hash FROM usuarios WHERE email = $1"
    user = await conn.fetchrow(query, req.email)
    
    if not user:
        raise HTTPException(status_code=401, detail="Email ou senha incorretos")
        
    # Verificar senha usando bcrypt puro
    is_password_correct = bcrypt.checkpw(
        req.password.encode('utf-8'), 
        user['senha_hash'].encode('utf-8')
    )
    
    if not is_password_correct:
        raise HTTPException(status_code=401, detail="Email ou senha incorretos")
    
    # Gerar payload do JWT conforme regra de negócio
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    payload = {
        "sub": str(user['id']),
        "escola_id": str(user['escola_id']),
        "role": user['papel'],
        "exp": expire
    }
    
    # Gerar o Token
    token = jwt.encode(payload, JWT_SECRET, algorithm=ALGORITHM)
    
    return {
        "access_token": token, 
        "token_type": "bearer",
        "escola_id": user['escola_id'],
        "role": user['papel']
    }

@app.get("/auth/health")
def health_check():
    return {"status": "ok", "service": "Auth Service"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8081, reload=True)
